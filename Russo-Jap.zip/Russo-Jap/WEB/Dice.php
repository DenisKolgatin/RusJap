<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<center>
<?php 
$im=rand(1, 6);

switch($im) {
   case 1:
      $binary='I';
      break;
   case 2:
      $binary='II';
      break;
   case 3:
      $binary='III';
      break;
   case 4:
      $binary='IV';
      break;
   case 5:
      $binary='V';
      break;
   case 6:
      $binary='VI';
      break;
}
print "<p>ИГРАЛЬНАЯ КОСТЬ</p><img src='Игральная кость/dice{$im}.png'<br/><p>вам выпало {$binary}</p><br/><p>для нового броска обновите страницу браузера</p>";
	if ($im == 1) {
  print "<p>это очко!</p>";
  } else {
   print "это не очко...";
}
?>
</center>
</body>
</html>

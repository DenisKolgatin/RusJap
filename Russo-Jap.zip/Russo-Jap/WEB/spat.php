<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<center>
<?php 
$im=rand(1, 7);

switch($im) {
   case 1:
      $binary='понедельник';
      break;
   case 2:
      $binary='вторник';
      break;
   case 3:
      $binary='среда';
      break;
   case 4:
      $binary='четверг';
      break;
   case 5:
      $binary='пятница';
      break;
   case 6:
      $binary='суббота';
      break;
   case 7:
      $binary='воскресенье';
      break;	  
}
print "<p>Можно ли еще поспать?</p><br/><p>для нового расчета обновите браузер</p><p>$im</p>";
	if ($binary=="суббота" or $binary=="воскресенье") {
  print "спите дальше!";
  } else {
   print "подъем!";
}
?>
</center>
</body>
</html>

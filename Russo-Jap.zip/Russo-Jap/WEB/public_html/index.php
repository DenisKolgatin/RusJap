<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Приключенческая игра</title>
<?php 
if(isset($_POST['точка'])){
	$carrentSituation=$_POST['точка'];
}else{
	$carrentSituation=1;
}


$conn = mysql_connect("localhost","kolgatin1","zaza");
$ans = mysql_select_db('kolgatin1_game',$conn);
$sql = "SELECT * FROM  adventure WHERE id=$carrentSituation";
$result = mysql_query($sql,$conn);
$situation = mysql_fetch_row($result);


$sql = "SELECT * FROM  adventure WHERE id=$situation[3]"; // север
$result = mysql_query($sql,$conn);
$север = mysql_fetch_row($result);
$sql = "SELECT * FROM  adventure WHERE id=$situation[4]"; // восток
$result = mysql_query($sql,$conn);
$восток = mysql_fetch_row($result);
$sql = "SELECT * FROM  adventure WHERE id=$situation[5]"; // юг
$result = mysql_query($sql,$conn);
$юг = mysql_fetch_row($result);
$sql = "SELECT * FROM  adventure WHERE id=$situation[6]"; // запад
$result = mysql_query($sql,$conn);
$запад = mysql_fetch_row($result);


?>
</head>

<body style="background-color:#0066FF">
<div style="width:90%; background-color:#9999FF; margin:auto; text-align:center;">
  <h1 style="color:#990000"><?php echo $situation[1] ?></h1>
  <form action="" method="post">
    <table width="700" align="center" cellpadding="5" cellspacing="0"  style="border:#990000 1px solid;">
      <tr>
        <td width="100">&nbsp;</td>
    <td><input name="точка" type="radio" value="<?php echo $situation[3] ?>" />
    <?php echo $север[1] ?></td>
    <td width="100">&nbsp;</td>
    </tr>
      <tr>
        <td height="50"><input name="точка" type="radio" value="<?php echo $situation[6] ?>" />
        <?php echo $запад[1] ?></td>
    <td  bgcolor="#FFCCFF"><?php echo $situation[2] ?></td>
    <td><input name="точка" type="radio" value="<?php echo $situation[4] ?>" />
    <?php echo $восток[1] ?></td>
    </tr>
      <tr>
        <td>&nbsp;</td>
    <td><input name="точка" type="radio" value="<?php echo $situation[5] ?>" />
    <?php echo $юг[1] ?></td>
    <td>&nbsp;</td>
    </tr>
    </table>
    <p>
      <input name="" type="submit" value="Вперёд" />
      </p>
  </form>
  <p>&nbsp;</p>
</div>
</body>
</html>

 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<center>
<?php 
$conn = mysql_connect('localhost','root','');
$ans = mysql_select_db('game',$conn);
?>
<form method="post">
<table width="339" border="1">
  <tr>
    <td colspan="2" align="center"><span class="style1">Регистрация</span></td>
  </tr>
  <tr>
    <td width="179" align="center">Логин</td>
    <td width="144"><input type="text" name="log" /></td>
  </tr>
  <tr>
    <td align="center">Пароль</td>
    <td><input type="password" name="pas" /></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="submit" value="отправить" /></td>
  </tr>
</table>
</form>
<?php 
	 if (isset($_POST['log'])){
	$login=$_POST['log'];
	$password=$_POST['pas'];
	trim($login);
	trim($password);
	$sql = "INSERT INTO subject (predmet) VALUES ('астрономия')";
$result = mysql_query($sql,$conn);
if(isset($_POST['login']) and isset($_POST['password'])) {
       $log=$_POST['login'];
       $pas=$_POST['password'];
       $dud=fopen('registration/registration.txt','r');
	   $find=0;
	   $log=trim($log);
		$pas=trim($pas);
			while (!feof($dud)){
            $logf=fgets($dud);
            $logf=trim($logf);
            $pasf=fgets($dud);
            $pasf=trim($pasf);
			$em=fgets($dud);
            $em=trim($em);									 
            if($log==$logf and $pas==$pasf) {
				$find=1;	
									}
										}
		fclose($dud);
			if ($find==1) {
                print ('вход выполнен') ;
								} else {
                                  ?>
             <form method="post">
              <h3>Логин</h3>
             <input type="text" name="login"  />
            <h3>Пароль</h3>
            <input type="password" name="password"  /><br />
            <input type="submit" value="вход" />
                                 </form>
                                  <?php 
                                   print 'неверный логин или пароль!';
                                }
                                 }else{
                                            ?>
                                            <form method="post">
                                            <h3>Логин</h3>
                                            <input type="text" name="login"  />
                                            <h3>Пароль</h3>
                                            <input type="password" name="password"  /><br />
                                            <input type="submit" value="вход" />
                                            </form>
                                            <?php 
if($result){
   print "<p>Вы успешно зарегестрировались</p>";
}
	else {
	print "<p>Регистрация провалена</p>";
	}
 
    

?>
</center>
</body>
</html>
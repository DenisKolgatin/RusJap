<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Русско-японская война</title>       
    <LINK href="style1.css" rel="stylesheet" type="text/css">       
</head>
<body>
<center>
<img src="imegis/логотип для сайта по истории.jpg" width="100%" height="257">
<table border="2" height="100%" width="100%">
<tr> 
    	<td colspan="5" align="left">
        	<table>
            	<tr>
                    <td width="204" height="50"  align="left" valign="top"><a href="text.html" target="content"><img src="imegis/flag.jpg"  height="134"></a></td>    
                    <td width="304" align="left" valign="top"><a href="источники.html" target="content"><img src="imegis/flag1.jpg"  height="134"></a></td>
                    <td width="404" align="center" valign="top"><a href="о нас.html" target="content"><img src="imegis/flag2.jpg" height="134"></a></a></td>
                    <td width="394" align="center" valign="middle"><a href="Народная память о русско-японской войне.html" target="content"><img src="imegis/народная память.jpg" height="134"></a></td> 
                    <td width="390" align="right"><a href="registration/registration.php" target="content"><img src="imegis/flag3.jpg" width="390"></a></td> 
              </tr>
          	</table>			</td>
  				</tr>
    			<tr>
    					<td colspan="1" width="264">
<table valign="top">
                                  <tr>
                                    <td>
                                            <?php 
                                            if(isset($_POST['login']) and isset($_POST['password'])) {
                                            $log=$_POST['login'];
                                            $pas=$_POST['password'];
                                            $dud=fopen('registration/registration.txt','r');
											$find=0;
											$log=trim($log);
											$pas=trim($pas);
										while (!feof($dud)){
                                            $logf=fgets($dud);
                                            $logf=trim($logf);
                                            $pasf=fgets($dud);
                                            $pasf=trim($pasf);
											$em=fgets($dud);
                                            $em=trim($em);									 
                                                if($log==$logf and $pas==$pasf) {
													$find=1;	
													}
										}
										     fclose($dud);
												if ($find==1) {
                                                ?><img src="imegis/Вход выполнен.jpg" /><?php ;
												}
                                                else {
                                                    ?>
                                                    <form method="post">
                                            <h3>Логин</h3>
                                            <input type="text" name="login"  />
                                            <h3>Пароль</h3>
                                            <input type="password" name="password"  /><br />
											<input type="submit" value="вход" />
                                            </form>
                                                    <?php 
                                                print 'неверный логин или пароль!';
                                                }
                                            }
                                            else{
                                            ?>
                                            <form method="post">
                                            <h3>Логин</h3>
                                            <input type="text" name="login"  />
                                            <h3>Пароль</h3>
                                            <input type="password" name="password"  /><br />
                                            <input type="submit" value="вход" />
                                            </form>
                                            <?php
                                            }
                                             ?>                 </td>
                                </tr>
                                <tr>
                                <td width="180" align="center" valign="top"><img src="imegis/12.jpg"  >                                </td></tr>
                                <tr>
                                    <td width="180" align="center" valign="top">
                                    <a href="начало войны.html" target="content"> <img src="imegis/pl1.jpg"  onMouseOver="this.src='imegis/pl11.jpg'"  onmouseout="this.src='imegis/pl1.jpg'"></a>
                                      
                                        <a href="Японское наступление в Маньчжурии, оборона и сдача Порт-Артура.html" target="content"><img src="imegis/pl2.jpg"  onMouseOver="this.src='imegis/pl22.jpg'"  onmouseout="this.src='imegis/pl2.jpg'"></a>
                                        <a href="Мукден.html" target="content"><img src="imegis/pl3.jpg"  onMouseOver="this.src='imegis/pl33.jpg'"  onmouseout="this.src='imegis/pl3.jpg'"></a>                                  </td>  
                                </tr>
                                <tr>
                                    <td width="180" align="center" valign="top"><img src="imegis/13.jpg"  >
                                    <h2>Генералы</h2>
                                                    
                                                     <a href="Генерал Кондратенко.html" target="content"><img src="imegis/pl4.jpg"  onMouseOver="this.src='imegis/pl44.jpg'"  onmouseout="this.src='imegis/pl4.jpg'"></a></li>
                                                     <a href="генерал Белый.htm" target="content"><img src="imegis/pl5.jpg"  onMouseOver="this.src='imegis/pl55.jpg'"  onmouseout="this.src='imegis/pl5.jpg'"></a>
                                                     <a href="Анатолий Михайлович Стессель.html" target="content"><img src="imegis/pl6.jpg"  onMouseOver="this.src='imegis/pl66.jpg'"  onmouseout="this.src='imegis/pl6.jpg'"></a>
                                                    
                                                    
                                   <h2>Адмиралы</h2>
                                                   
                                                     <a href="Макаров, Степан Осипович.html" target="content"><img src="imegis/pl7.jpg"  onMouseOver="this.src='imegis/pl77.jpg'"  onmouseout="this.src='imegis/pl7.jpg'"></a>
                                                <a href="Того Хэйхатиро.html" target="content"><img src="imegis/pl8.jpg"  onMouseOver="this.src='imegis/pl88.jpg'"  onmouseout="this.src='imegis/pl8.jpg'"></a>
                                                    <a href="Рожественский, Зиновий Петрович.html" target="content"><img src="imegis/pl9.jpg"  onMouseOver="this.src='imegis/pl99.jpg'"  onmouseout="this.src='imegis/pl9.jpg'"></a>                                    </td>
</tr>  
                                <tr>
                                    <td align="center"><h2>флот</h2>
                                    
                                        <a href="галерея кораблей.html" target="content"><img src="imegis/pl10.jpg"  onMouseOver="this.src='imegis/pl100.jpg'"  onmouseout="this.src='imegis/pl10.jpg'"></a>                                    </td>
                                </tr>
                                <tr>
                                    <td align="center"> <a href="вывод.html" target="content"><img src="imegis/pl1111.jpg"  onMouseOver="this.src='imegis/pl111.jpg'"  onmouseout="this.src='imegis/pl1111.jpg'"></a></td>
                                </tr>                                            
                            </table></td>
    	<td width="1454" colspan="4" align="left"><iframe src="text.html" name="content" width="100%" height="100%" id="content"> </iframe></td>
  </tr>
    <tr>
    	<td height="21" colspan="5" bgcolor="#666666"><p>&#169;kolgatines (<a href="mailto:kolgatines@gmail.com">почта</a>)</p></td>
    </tr>
</table>
</center>
</body>
</html>

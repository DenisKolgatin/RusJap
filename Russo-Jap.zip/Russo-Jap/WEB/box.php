<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>box</title>
</head>

<body>
<?php 
$x=rand(1,10);
$y=rand(1,10);
print 'x=';
print $x;
print 'y=';
print $y;
if (($x>3 and $x<7) and ($y>3 and $y<7)) {
print 'ты попал';
}
else {
print 'ты не попал';
}

?>
</body>
</html>

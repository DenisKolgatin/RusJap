<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<center>
<?php 
$im = rand(1,6);
print "<p>ИГРАЛЬНАЯ КОСТЬ</p><img src='Игральная кость/dice{$im}.png'<br/><p>вам выпало {$im}</p><br/><p>для нового броска обновите страницу браузера</p>";
	if ($im == 1) {
  print "a больше, чем b";
  $b = $a;
}
?>
</center>
</body>
</html>

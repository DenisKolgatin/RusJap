<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>лепестки</title>
</head>

<body>
<center>
<table style="border-color:#0099FF; border-style:groove;">
	<tr>
    	<td>
<center>
<table>
	<tr>
		<td colspan="9" align="center">
			<h2>Лепестки розы</h2>		</td>
    </tr>
    <tr>
            <td><?php
		$im=rand(1, 6);
		print "<img width='50' src='Игральная кость/dice{$im}.png'<br/><br/>";
		$binary=calcular($im);
?></td>
		<td>
		<?php
		$im=rand(1, 6);
		print "<img width='50' src='Игральная кость/dice{$im}.png'<br/><br/>";
		$binary1=calcular($im);
?></td>
	    <td><?php
		$im=rand(1, 6);
		print "<img width='50' src='Игральная кость/dice{$im}.png'<br/><br/>";
		$binary2=calcular($im);
?></td>
        <td><?php
		$im=rand(1, 6);
		print "<img width='50' src='Игральная кость/dice{$im}.png'<br/><br/>";
		$binary3=calcular($im);
?></td>
        <td><?php
		$im=rand(1, 6);
		print "<img width='50' src='Игральная кость/dice{$im}.png'<br/><br/>";
		$binary4=calcular($im);
?></td>
    </tr>
  </table>
<table>
     <tr>
     	<td colspan="5" align="center" valign="middle"><?php
		$summa=$binary+$binary1+$binary2+$binary3+$binary4; ?></td>
     </tr>
</table>
<p>
  <?php $am=rand(1,6);
?>
</p>
<p>
  <?php 
function calcular ($im) {
switch($im) {
   case 1:
      $binary='0';
      break;
   case 2:
      $binary='0';
      break;
   case 3:
      $binary='2';
      break;
   case 4:
      $binary='0';
      break;
   case 5:
      $binary='4';
      break;
   case 6:
      $binary='0';
      break;
}
	  return $binary;
} 
if (isset($_POST['T1'])) {
	$P1 = $_POST['T1'];
	$P2 = $_POST['T2'];
	if ($P1==$P2) {?>
</p>
<h4 style="color:#FF9933">Вы угадали!</h4>
<?php 
	} else {  ?>
<h4>Вы неугадали! Попробуйте еще раз!</h4>
<?php
	}
 } ?>
<form method="post">
<p>введите количество лепестков</p>
<input type="text" name="T1"  />
<input type="hidden" name="T2" value="<?php print $summa; ?>"  />
<input type="submit" value="отправить" />
</form>
</center>
		</td>
  	</tr>
  </table>
  </center>
</body>
</html>

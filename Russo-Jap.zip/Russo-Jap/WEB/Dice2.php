<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Кости</title>
</head>

<body>
<center>
<form action="Dice2.php" method="post">
<table style="border-color:#0099FF; border-style:groove;">
	<tr>
    	<td colspan="3" align="center" valign="middle"><h2>Игральная кость</h2></td>
    </tr>
    <tr>
    	<td><p>угадайте, что вам выпадет:</p></td>
        <td><input type="text" name="a1"  /></td>
        <td><input type="submit" value="пуск" /></td>
    </tr>
    <tr>
    	<td colspan="3" align="center">
		 <?php
		 if (isset($_POST['a1'])) { 
$im=rand(1, 6);
print "<img width='50' src='Игральная кость/dice{$im}.png'<br/><p>вам выпало {$im}</p><br/>";
?></td>
    </tr>
    <tr>
    	<td colspan="3" align="center"><?php 
		$var =$_POST['a1'];
		if ($var==$im){
		print ('вы угадали!');
		}
		else {
		print ('вы не угадали');
		}
		?></td>
    </tr>
</table>
<?php }
?>
</form>
</center>
</body>
</html>

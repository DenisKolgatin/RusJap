﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>registration</title>
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<center>
<form method="post">
<table width="339" border="1">
  <tr>
    <td colspan="2" align="center"><span class="style1">Регистрация</span></td>
  </tr>
  <tr>
    <td width="179" align="center">Логин</td>
    <td width="144"><input type="text" name="log" /></td>
  </tr>
  <tr>
    <td align="center">Пароль</td>
    <td><input type="password" name="pas" /></td>
  </tr>
  <tr>
    <td align="center">Почта</td>
    <td><input type="text" name="em" /></td>
  </tr>  
  <tr>
    <td colspan="2" align="center"><input type="submit" value="отправить" /></td>
  </tr>
</table>
</form>
<?php 
	 if (isset($_POST['log'])){
	$login=$_POST['log'];
	$password=$_POST['pas'];
	$Em=$_POST['em'];
	trim($login);
	trim($password);
	trim($Em);
	$fp=fopen('registration.txt','a');
	$text=" $login \n $password \n $Em \n";
	fputs($fp,$text);
	fclose($fp);
print "регистрация успешна"; 
}
?>
</center>
</body>
</html>